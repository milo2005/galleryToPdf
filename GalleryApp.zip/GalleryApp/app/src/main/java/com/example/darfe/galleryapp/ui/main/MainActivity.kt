package com.example.darfe.galleryapp.ui.main

import android.content.Intent
import android.os.Bundle
import android.support.v7.app.AppCompatActivity
import com.example.darfe.galleryapp.ui.gallery.GalleryActivity
import com.example.darfe.galleryapp.R
import com.example.darfe.galleryapp.util.LifeDisposable
import com.example.darfe.galleryapp.util.PhotoUtil
import com.jakewharton.rxbinding2.view.clicks
import kotlinx.android.synthetic.main.activity_main.*
import org.jetbrains.anko.startActivity

class MainActivity : AppCompatActivity() {

    val dis:LifeDisposable = LifeDisposable(this)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
    }

    override fun onResume() {
        super.onResume()

        dis add btnTake.clicks()
            .subscribe { PhotoUtil.captureImage(this) }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        PhotoUtil.getPath(resultCode)?.run {
            startActivity<GalleryActivity>(GalleryActivity.EXTRA_PATH to this)
        }
    }
}
