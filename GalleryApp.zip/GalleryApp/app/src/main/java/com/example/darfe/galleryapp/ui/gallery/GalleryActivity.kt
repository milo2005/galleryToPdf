package com.example.darfe.galleryapp.ui.gallery

import android.os.Bundle
import android.support.v7.app.AppCompatActivity
import android.view.Menu
import android.view.MenuItem
import com.example.darfe.galleryapp.R
import com.example.darfe.galleryapp.ui.gallery.adapter.PhotoAdapter
import com.example.darfe.galleryapp.util.LifeDisposable
import com.jakewharton.rxbinding2.view.clicks
import kotlinx.android.synthetic.main.activity_gallery.*

class GalleryActivity : AppCompatActivity() {

    private val dis: LifeDisposable = LifeDisposable(this)
    private val adapter: PhotoAdapter by lazy { PhotoAdapter(supportFragmentManager) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_gallery)
        setSupportActionBar(bottomBar)
        intent.extras?.getString(EXTRA_PATH)?.run(adapter::add)
    }

    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        menuInflater.inflate(R.menu.menu_gallery, menu)
        return super.onCreateOptionsMenu(menu)
    }

    override fun onOptionsItemSelected(item: MenuItem?): Boolean {
        when (item?.itemId) {
            R.id.action_add -> {
            }
            R.id.action_crop -> {
            }
            R.id.action_rotate -> {
            }
            R.id.action_delete -> if (adapter.remove(pager.currentItem)) finish()
        }
        return super.onOptionsItemSelected(item)
    }

    override fun onResume() {
        super.onResume()

        dis add btnBack.clicks()
            .subscribe { finish() }

        dis add btnOk.clicks()
            .subscribe { }
    }

    companion object {
        val EXTRA_PATH = "img_path"
    }

}
