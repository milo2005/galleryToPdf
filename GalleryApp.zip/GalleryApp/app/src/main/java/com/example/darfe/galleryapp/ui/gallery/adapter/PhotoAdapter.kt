package com.example.darfe.galleryapp.ui.gallery.adapter

import android.support.v4.app.Fragment
import android.support.v4.app.FragmentManager
import android.support.v4.app.FragmentStatePagerAdapter
import com.example.darfe.galleryapp.ui.gallery.PhotoFragment

class PhotoAdapter(fm: FragmentManager) : FragmentStatePagerAdapter(fm) {

    val data: MutableList<String> = mutableListOf()

    override fun getItem(p0: Int): Fragment  = PhotoFragment.instance(data[p0])

    override fun getCount(): Int = data.size

    fun add(uri:String){
        data.add(uri)
        notifyDataSetChanged()
    }

    fun remove(position:Int):Boolean{
        data.removeAt(position)
        return data.isEmpty()
    }

}